# EcoCollect

EcoCollect is a Uganda-focused waste collection management application. This repository currently contains the first implementation milestone: Supabase phone OTP authentication and a verified, pending customer application flow.

## Architecture and delivery stages

1. **Foundation and customer onboarding (implemented):** Vite, React, TypeScript, responsive interface, Supabase phone OTP, database-backed customer profiles and plans, RLS, GPS capture, and atomic pending applications.
2. **Customer and administrator operations:** approval controls, customer directory, configurable plans, subscriptions, negotiated prices, and account status.
3. **Collection operations:** staff assignment, routes, schedules, collection completion history, and operational dashboards.
4. **Finance:** invoices, payment records and allocations, clearance calculations, expenses, and audited privileged actions.
5. **Reporting and deployment:** date-correct weekly/monthly reporting, PDF/Excel exports, broader authorization/business-logic tests, and production operations guidance.

The first migration intentionally establishes only the tables needed for onboarding. It does not claim that later finance, staff, reporting, or collection workflows are implemented.

## Local setup

Requirements: Node.js 20+ and a Supabase project.

1. Install dependencies with `npm install`.
2. Copy `.env.example` to `.env` and set:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY` (the publishable/anon key only)
3. Apply `supabase/migrations/202611060001_initial_customer_onboarding.sql` using the Supabase CLI (`supabase db push`) or your managed migration workflow. Do not edit the production database manually.
4. In Supabase Auth, disable **User Signups** and enable **Phone** authentication, then configure an SMS provider suitable for Uganda. Set OTP expiry, rate limits, and production SMS credentials in Supabase; never put the provider secret in this frontend. New users must be provisioned by an authorized administrator or existing setup process rather than through the public app.
5. Ensure your SMS provider accepts the `+256` E.164 format and test delivery/OTP verification before inviting customers.
6. Create at least one active `service_plans` row with a business-approved price before enabling registration. The application deliberately does not seed or invent prices.
7. Start the development server with `npm start` (or `npm run dev`). Run `npm run build` for a production build.

## Trusted administrator provisioning

New Supabase Auth accounts always receive the `customer` database role. Client metadata cannot grant staff or administrator access. Promote the initial administrator using a trusted, authenticated database migration or restricted SQL session, for example:

```sql
update public.profiles p
set role = 'administrator'
from auth.users u
where p.id = u.id
  and u.phone = '+256700000000';
```

Replace the example phone number with the verified administrator's number. Do not expose a service-role key or run this operation from the browser. The administrator/staff portals are not part of this milestone.

## Security and current scope

- RLS is enabled for every table in the initial migration.
- Customers can read only their own profile, customer details, and subscription. Staff/admin reads use trusted roles stored in `public.profiles`.
- New auth users receive a customer role through a database trigger; users cannot write their own role or approval status.
- Customer and subscription records are created together by `submit_customer_application`, which verifies the authenticated user and verified Uganda phone, checks the active plan, and snapshots its price/frequency.
- The frontend only uses the Supabase anon key. SMS provider credentials and the service-role key remain server-side.
- No Maps API is required for this milestone: customers may grant browser geolocation permission or enter coordinates manually. A map pin-selection integration is a later UX enhancement.

Do not treat the application as production-ready for financial or collection operations until the remaining stages, database policies, deployment hardening, and end-to-end tests have been completed.
