import { useState } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./auth/AuthProvider";
import { AuthPage } from "./pages/AuthPage";
import { CustomerPortal } from "./pages/CustomerPortal";
import { isSupabaseConfigured } from "./lib/supabase";

function App() {
  const { session, profile, loading } = useAuth();

  if (!isSupabaseConfigured) {
    return (
      <main className="setup-screen">
        <section className="setup-card">
          <div className="brand-mark">E</div>
          <p className="eyebrow">EcoCollect setup</p>
          <h1>Connect your Supabase project</h1>
          <p>
            Add <code>VITE_SUPABASE_URL</code> and{" "}
            <code>VITE_SUPABASE_ANON_KEY</code> to your local <code>.env</code>,
            apply the included migration, and configure phone OTP before running
            the app.
          </p>
        </section>
      </main>
    );
  }

  return (
    <Routes>
      <Route
        path="/"
        element={
          loading ? (
            <LoadingScreen />
          ) : session ? (
            profile?.role === "customer" ? (
              <Navigate to="/customer" replace />
            ) : profile ? (
              <Navigate to="/unsupported-role" replace />
            ) : (
              <ProfileUnavailable />
            )
          ) : (
            <AuthPage />
          )
        }
      />
      <Route
        path="/customer"
        element={
          loading ? (
            <LoadingScreen />
          ) : session && profile?.role === "customer" ? (
            <CustomerPortal />
          ) : (
            <Navigate to="/" replace />
          )
        }
      />
      <Route
        path="/continue-registration"
        element={
          loading ? (
            <LoadingScreen />
          ) : session && profile?.role === "customer" ? (
            <AuthPage authenticated initialPhone={session.user.phone ?? ""} />
          ) : (
            <Navigate to="/" replace />
          )
        }
      />
      <Route
        path="/unsupported-role"
        element={
          <main className="setup-screen">
            <section className="setup-card">
              <div className="brand-mark">E</div>
              <p className="eyebrow">EcoCollect</p>
              <h1>This workspace is not available yet</h1>
              <p>
                Your account role is recognized. The administrator and
                collection-staff portals are part of the next implementation
                milestone.
              </p>
            </section>
          </main>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function ProfileUnavailable() {
  const { signOut } = useAuth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleSignOut() {
    setBusy(true);
    try {
      await signOut();
    } catch (signOutError) {
      setError(signOutError instanceof Error ? signOutError.message : "Could not sign out.");
      setBusy(false);
    }
  }

  return (
    <main className="setup-screen">
      <section className="setup-card">
        <div className="brand-mark">E</div>
        <p className="eyebrow">EcoCollect account</p>
        <h1>We couldn’t load your account</h1>
        <p>
          Your sign-in succeeded, but the account profile is unavailable. Please
          contact EcoCollect support before trying again.
        </p>
        {error && <div className="alert alert-error" role="alert">{error}</div>}
        <button className="button button-primary" onClick={handleSignOut} disabled={busy}>
          {busy ? "Signing out…" : "Sign out"}
        </button>
      </section>
    </main>
  );
}

function LoadingScreen({ message = "Checking your account…" }: { message?: string }) {
  return (
    <main className="setup-screen" aria-live="polite">
      <div className="loading-indicator">
        <span className="spinner" />
        {message}
      </div>
    </main>
  );
}

export default App;
