import { useEffect, useState, type FormEvent } from "react";
import {
  ArrowRight,
  MapPin,
  Recycle,
  ShieldCheck,
  Smartphone,
  Truck
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";

interface ServicePlan {
  id: string;
  name: string;
  frequency: string;
  collections_per_period: number;
  price_ugx: number;
}

interface ApplicationForm {
  fullName: string;
  phone: string;
  district: string;
  town: string;
  division: string;
  area: string;
  village: string;
  street: string;
  houseNumber: string;
  landmark: string;
  latitude: string;
  longitude: string;
  planId: string;
}

const blankForm: ApplicationForm = {
  fullName: "",
  phone: "+256",
  district: "",
  town: "",
  division: "",
  area: "",
  village: "",
  street: "",
  houseNumber: "",
  landmark: "",
  latitude: "",
  longitude: "",
  planId: ""
};

const ugx = new Intl.NumberFormat("en-UG", {
  style: "currency",
  currency: "UGX",
  maximumFractionDigits: 0
});

export function AuthPage({
  authenticated = false,
  initialPhone
}: {
  authenticated?: boolean;
  initialPhone?: string;
}) {
  const [mode, setMode] = useState<"register" | "signin">("register");
  const [form, setForm] = useState(() => ({
    ...blankForm,
    phone: initialPhone || blankForm.phone
  }));
  const [plans, setPlans] = useState<ServicePlan[]>([]);
  const [plansLoading, setPlansLoading] = useState(true);
  const [plansError, setPlansError] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [busy, setBusy] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [infoMessage, setInfoMessage] = useState("");
  const [locating, setLocating] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    let active = true;
    async function loadPlans() {
      if (!supabase) return;
      setPlansLoading(true);
      const { data, error } = await supabase
        .from("service_plans")
        .select("id, name, frequency, collections_per_period, price_ugx")
        .eq("is_active", true)
        .order("price_ugx", { ascending: true });

      if (!active) return;
      if (error) setPlansError("Could not load available service plans.");
      else {
        const availablePlans = data ?? [];
        setPlans(availablePlans);
        if (availablePlans.length === 1) {
          setForm((current) => ({
            ...current,
            planId: current.planId || availablePlans[0].id
          }));
        }
      }
      setPlansLoading(false);
    }
    void loadPlans();
    return () => {
      active = false;
    };
  }, []);

  function updateField<K extends keyof ApplicationForm>(
    key: K,
    value: ApplicationForm[K]
  ) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function validatePhone(value: string) {
    return /^\+256\d{9}$/.test(value);
  }

  async function submitApplication() {
    if (!supabase) return;
    const { error } = await supabase.rpc("submit_customer_application", {
      p_full_name: form.fullName.trim(),
      p_district: form.district.trim(),
      p_town: form.town.trim(),
      p_division: form.division.trim() || null,
      p_area: form.area.trim() || null,
      p_village: form.village.trim() || null,
      p_street: form.street.trim() || null,
      p_house_number: form.houseNumber.trim() || null,
      p_landmark: form.landmark.trim() || null,
      p_latitude: form.latitude ? Number(form.latitude) : null,
      p_longitude: form.longitude ? Number(form.longitude) : null,
      p_service_plan_id: form.planId
    });

    if (error) {
      setBusy(false);
      setErrorMessage(
        error.code === "23505"
          ? "An application already exists for this phone number. Sign in to view its status."
          : error.message
      );
      return;
    }
    navigate("/customer", { replace: true });
  }

  async function requestCode(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase) return;
    setErrorMessage("");
    setInfoMessage("");

    if (!validatePhone(form.phone.trim())) {
      setErrorMessage("Enter a valid Ugandan mobile number in +256XXXXXXXXX format.");
      return;
    }
    const shouldCreateUser = mode === "register";
    if (mode === "register" || authenticated) {
      if (!form.fullName.trim() || !form.district.trim() || !form.town.trim()) {
        setErrorMessage("Enter your full name, district and town to continue.");
        return;
      }
      if (!form.planId) {
        setErrorMessage("Choose an available collection plan to continue.");
        return;
      }
      if (form.latitude || form.longitude) {
        const latitude = Number(form.latitude);
        const longitude = Number(form.longitude);
        if (!form.latitude || !form.longitude || !Number.isFinite(latitude) ||
            !Number.isFinite(longitude) || Math.abs(latitude) > 90 ||
            Math.abs(longitude) > 180) {
          setErrorMessage("Enter a valid latitude and longitude pair.");
          return;
        }
      }
      setBusy(true);
      await submitApplication();
      return;
    }

    setBusy(true);
    const { error } = await supabase.auth.signInWithOtp({
      phone: form.phone.trim(),
      options: { shouldCreateUser }
    });
    setBusy(false);
    if (error) {
      if (/signups not allowed/i.test(error.message)) {
        setErrorMessage(
          "No account exists for this phone number, or phone sign-ups are disabled. Contact EcoCollect before requesting another code."
        );
      } else {
        setErrorMessage(
          error.message.includes("already")
            ? "This number already has an account. Sign in instead."
            : error.message
        );
      }
      return;
    }
    setOtpSent(true);
    setInfoMessage(`A verification code has been sent to ${form.phone.trim()}.`);
  }

  async function verifyCode(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase) return;
    setErrorMessage("");
    setInfoMessage("");
    if (!/^\d{6}$/.test(otp)) {
      setErrorMessage("Enter the 6-digit code from your SMS.");
      return;
    }

    setBusy(true);
    const { data, error } = await supabase.auth.verifyOtp({
      phone: form.phone.trim(),
      token: otp,
      type: "sms"
    });
    if (error) {
      setBusy(false);
      setErrorMessage(error.message);
      return;
    }

    if (!data.session) {
      setBusy(false);
      setErrorMessage("Verification succeeded but no session was created. Please sign in.");
      return;
    }
    if (mode === "register") {
      await submitApplication();
      return;
    }
    setBusy(false);
    navigate("/customer", { replace: true });
  }

  function captureLocation() {
    setErrorMessage("");
    if (!navigator.geolocation) {
      setErrorMessage("Location capture is not supported by this browser.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        updateField("latitude", position.coords.latitude.toFixed(7));
        updateField("longitude", position.coords.longitude.toFixed(7));
        setLocating(false);
      },
      (error) => {
        setLocating(false);
        setErrorMessage(
          error.code === error.PERMISSION_DENIED
            ? "Location permission was denied. You can enter coordinates manually."
            : "Could not get your location. Check your device settings and try again."
        );
      },
      { enableHighAccuracy: true, timeout: 12000 }
    );
  }

  return (
    <main className="auth-layout">
      <aside className="brand-panel">
        <div className="brand-lockup">
          <div className="brand-mark"><Recycle size={23} strokeWidth={2.2} /></div>
          <span>EcoCollect</span>
        </div>
        <div className="brand-copy">
          <p className="eyebrow light">A cleaner tomorrow starts here</p>
          <h1>Good waste habits make <em>great</em> communities.</h1>
          <p className="brand-description">
            Reliable, responsible waste collection for homes and businesses
            across Uganda.
          </p>
          <div className="brand-benefits">
            <div><Truck size={18} /><span>Dependable local collection</span></div>
            <div><MapPin size={18} /><span>Service built around your area</span></div>
            <div><ShieldCheck size={18} /><span>Secure account and payment records</span></div>
          </div>
        </div>
        <div className="brand-footer">Cleaner streets. Healthier neighbourhoods.</div>
        <div className="brand-orb brand-orb-one" />
        <div className="brand-orb brand-orb-two" />
      </aside>

      <section className="form-panel">
        <div className="mobile-brand">
          <div className="brand-mark"><Recycle size={21} /></div>
          <span>EcoCollect</span>
        </div>
        <>
            <div className="form-heading">
              <p className="eyebrow">{mode === "register" ? "Join EcoCollect" : "Welcome back"}</p>
              <h2>{mode === "register" ? "Create your account" : "Sign in to your account"}</h2>
              <p>{mode === "register" ? "A few details now, a cleaner space from here." : "Enter your Ugandan phone number to receive a secure sign-in code."}</p>
            </div>

            {!authenticated && <div className="mode-switch" role="tablist" aria-label="Account action">
              <button
                className={mode === "register" ? "active" : ""}
                onClick={() => { setMode("register"); setOtpSent(false); setErrorMessage(""); }}
                disabled={otpSent}
                role="tab"
                aria-selected={mode === "register"}
              >Create account</button>
              <button
                className={mode === "signin" ? "active" : ""}
                onClick={() => { setMode("signin"); setOtpSent(false); setErrorMessage(""); }}
                disabled={otpSent}
                role="tab"
                aria-selected={mode === "signin"}
              >Sign in</button>
            </div>}

            {!otpSent ? (
              <form className="application-form" onSubmit={requestCode}>
                {(authenticated || mode === "register") && (
                  <>
                    <div className="form-section-title">
                      <span className="step-number">01</span>
                      <div><strong>Your details</strong><small>Tell us where to find you</small></div>
                    </div>
                    <label className="field-label">
                      Full name <span aria-hidden="true">*</span>
                      <input autoComplete="name" value={form.fullName} onChange={(e) => updateField("fullName", e.target.value)} placeholder="e.g. Amina Namusoke" required />
                    </label>
                    <div className="field-grid">
                      <label className="field-label">District <span aria-hidden="true">*</span><input value={form.district} onChange={(e) => updateField("district", e.target.value)} placeholder="e.g. Kampala" required /></label>
                      <label className="field-label">Town / municipality <span aria-hidden="true">*</span><input value={form.town} onChange={(e) => updateField("town", e.target.value)} placeholder="e.g. Nakawa" required /></label>
                    </div>
                    <div className="field-grid">
                      <label className="field-label">Division<input value={form.division} onChange={(e) => updateField("division", e.target.value)} /></label>
                      <label className="field-label">Area / neighbourhood<input value={form.area} onChange={(e) => updateField("area", e.target.value)} /></label>
                    </div>
                    <div className="field-grid">
                      <label className="field-label">Village<input value={form.village} onChange={(e) => updateField("village", e.target.value)} /></label>
                      <label className="field-label">Street<input value={form.street} onChange={(e) => updateField("street", e.target.value)} /></label>
                    </div>
                    <div className="field-grid">
                      <label className="field-label">House number<input value={form.houseNumber} onChange={(e) => updateField("houseNumber", e.target.value)} /></label>
                      <label className="field-label">Nearby landmark<input value={form.landmark} onChange={(e) => updateField("landmark", e.target.value)} /></label>
                    </div>
                    <div className="location-box">
                      <div className="location-heading"><MapPin size={17} /><div><strong>Collection location</strong><small>Optional coordinates</small></div></div>
                      <button type="button" className="button button-outline location-button" onClick={captureLocation} disabled={locating}>
                        {locating ? <span className="spinner small" /> : <MapPin size={16} />}{locating ? "Finding location…" : "Use my current location"}
                      </button>
                      <div className="field-grid coordinate-fields">
                        <label className="field-label">Latitude<input inputMode="decimal" value={form.latitude} onChange={(e) => updateField("latitude", e.target.value)} placeholder="0.3476" /></label>
                        <label className="field-label">Longitude<input inputMode="decimal" value={form.longitude} onChange={(e) => updateField("longitude", e.target.value)} placeholder="32.5825" /></label>
                      </div>
                    </div>
                    <div className="form-section-title plan-title">
                      <span className="step-number">02</span>
                      <div><strong>Choose a collection plan</strong><small>Prices are set by EcoCollect</small></div>
                    </div>
                    {plansLoading ? (
                      <div className="inline-loading"><span className="spinner small" /> Loading available plans…</div>
                    ) : plansError ? (
                      <p className="inline-error">{plansError} Refresh the page to try again.</p>
                    ) : plans.length === 0 ? (
                      <div className="empty-plans"><Smartphone size={19} /><p>No collection plans are available yet. Please contact EcoCollect to continue.</p></div>
                    ) : (
                      <div className="plan-list">
                        {plans.map((plan) => (
                          <label className={`plan-option ${form.planId === plan.id ? "selected" : ""}`} key={plan.id}>
                            <input type="radio" name="plan" value={plan.id} checked={form.planId === plan.id} onChange={() => updateField("planId", plan.id)} />
                            <span className="plan-radio" />
                            <span className="plan-copy"><strong>{plan.name}</strong><small>{plan.collections_per_period} collection{plan.collections_per_period === 1 ? "" : "s"} · {plan.frequency}</small></span>
                            <span className="plan-price">{ugx.format(plan.price_ugx)}</span>
                          </label>
                        ))}
                      </div>
                    )}
                  </>
                )}
                {!authenticated && <>
                  <div className="form-section-title">
                    <div><strong>Verify your phone</strong><small>We’ll send a one-time code by SMS</small></div>
                  </div>
                  <label className="field-label">
                  Ugandan mobile number <span aria-hidden="true">*</span>
                  <div className="phone-input">
                    <Smartphone size={17} />
                    <input type="tel" autoComplete="tel" value={form.phone} onChange={(e) => updateField("phone", e.target.value)} placeholder="+256701234567" required />
                  </div>
                  <small className="field-hint">Use international format, for example +256701234567</small>
                  </label>
                </>}
                {authenticated && (
                  <div className="alert alert-info" role="status">
                    Phone verified: {form.phone}. Your application will be linked to this account.
                  </div>
                )}

                {errorMessage && <div className="alert alert-error" role="alert">{errorMessage}</div>}
                {infoMessage && <div className="alert alert-info" role="status">{infoMessage}</div>}
                <button className="button button-primary full-button" disabled={busy} type="submit">
                  {busy ? <><span className="spinner small light-spinner" /> {authenticated ? "Submitting…" : "Sending code…"}</> : <>{authenticated ? "Submit for approval" : "Send verification code"} <ArrowRight size={17} /></>}
                </button>
                <p className="privacy-note"><ShieldCheck size={14} /> Your phone number is verified securely. Standard SMS charges may apply.</p>
              </form>
            ) : (
              <form className="otp-form" onSubmit={verifyCode}>
                <div className="otp-icon"><Smartphone size={25} /></div>
                <h3>Check your messages</h3>
                <p>Enter the 6-digit code sent to <strong>{form.phone}</strong>.</p>
                <label className="field-label">Verification code
                  <input className="otp-input" inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="000000" required />
                </label>
                {errorMessage && <div className="alert alert-error" role="alert">{errorMessage}</div>}
                {infoMessage && <div className="alert alert-info" role="status">{infoMessage}</div>}
                <button className="button button-primary full-button" disabled={busy} type="submit">
                  {busy ? <><span className="spinner small light-spinner" /> Verifying…</> : <>Verify and continue <ArrowRight size={17} /></>}
                </button>
                <button type="button" className="text-button" onClick={() => { setOtpSent(false); setOtp(""); setErrorMessage(""); }}>Change phone number</button>
              </form>
            )}
        </>
        <footer className="form-footer">© {new Date().getFullYear()} EcoCollect Uganda <span>·</span> Responsible waste, reliable service</footer>
      </section>
    </main>
  );
}
