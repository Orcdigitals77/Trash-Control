import { useEffect, useState } from "react";
import { LogOut, MapPin, Recycle, ShieldCheck } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthProvider";
import { supabase } from "../lib/supabase";

interface CustomerDetails {
  full_name: string;
  district: string;
  town: string;
  area: string | null;
  approval_status: "pending" | "approved" | "rejected";
  created_at: string;
}

export function CustomerPortal() {
  const { session, signOut } = useAuth();
  const [details, setDetails] = useState<CustomerDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [signingOut, setSigningOut] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    let active = true;
    async function loadDetails() {
      if (!supabase || !session?.user.id) return;
      const { data, error: queryError } = await supabase
        .from("customer_details")
        .select("full_name, district, town, area, approval_status, created_at")
        .eq("profile_id", session.user.id)
        .maybeSingle();
      if (!active) return;
      if (queryError) setError("Could not load your account details. Please refresh to try again.");
      else setDetails(data as CustomerDetails | null);
      setLoading(false);
    }
    void loadDetails();
    return () => {
      active = false;
    };
  }, [session]);

  async function handleSignOut() {
    setSigningOut(true);
    try {
      await signOut();
      navigate("/", { replace: true });
    } catch (signOutError) {
      setError(signOutError instanceof Error ? signOutError.message : "Could not sign out.");
      setSigningOut(false);
    }
  }

  const status = details?.approval_status ?? "pending";
  return (
    <main className="portal-screen">
      <header className="portal-header">
        <div className="brand-lockup">
          <div className="brand-mark"><Recycle size={21} /></div>
          <span>EcoCollect</span>
        </div>
        <button className="button button-outline signout-button" onClick={handleSignOut} disabled={signingOut}>
          <LogOut size={16} /> {signingOut ? "Signing out…" : "Sign out"}
        </button>
      </header>
      <section className="portal-content">
        <p className="eyebrow">Customer account</p>
        {loading ? (
          <div className="inline-loading"><span className="spinner small" /> Loading your account…</div>
        ) : error ? (
          <div className="alert alert-error" role="alert">{error}</div>
        ) : !details ? (
          <div className="portal-card">
            <div className="status-icon pending"><ShieldCheck size={24} /></div>
            <h1>Finish your application</h1>
            <p>
              Your phone is verified, but no customer application is linked to
              this account yet. Continue your application to request service.
            </p>
            <button className="button button-primary" onClick={() => navigate("/continue-registration")}>
              Continue registration
            </button>
          </div>
        ) : (
          <>
            <h1>Hello, {details.full_name.split(" ")[0]}</h1>
            <p className="portal-intro">Your EcoCollect service application at a glance.</p>
            <div className="portal-card">
              <div className={`status-icon ${status}`}><ShieldCheck size={24} /></div>
              <div className={`status-pill ${status}`}>{status === "pending" ? "Pending review" : status}</div>
              <h2>{status === "pending" ? "Your application is with our team" : status === "approved" ? "Your account is active" : "Application needs attention"}</h2>
              <p>
                {status === "pending"
                  ? "We’ve received your details. An EcoCollect administrator will review your application before service begins."
                  : status === "approved"
                    ? "Your account has been approved. Collection schedules and account services will appear here as they become available."
                    : "Please contact EcoCollect for help with your application."}
              </p>
              <div className="account-summary">
                <div><MapPin size={17} /><span><strong>Service area</strong>{[details.area, details.town, details.district].filter(Boolean).join(", ")}</span></div>
                <div><ShieldCheck size={17} /><span><strong>Application submitted</strong>{new Date(details.created_at).toLocaleDateString("en-UG", { dateStyle: "long" })}</span></div>
              </div>
            </div>
          </>
        )}
        <p className="portal-footnote">For account assistance, please contact the EcoCollect team.</p>
      </section>
    </main>
  );
}
