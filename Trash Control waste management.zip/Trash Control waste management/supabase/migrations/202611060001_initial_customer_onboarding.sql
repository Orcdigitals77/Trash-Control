create extension if not exists pgcrypto;

create type public.app_role as enum ('administrator', 'staff', 'customer');
create type public.collection_frequency as enum ('daily', 'weekly', 'monthly', 'custom');
create type public.approval_status as enum ('pending', 'approved', 'rejected');
create type public.subscription_status as enum ('pending', 'active', 'suspended', 'ended');

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  role public.app_role not null default 'customer',
  full_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.service_plans (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(btrim(name)) between 2 and 100),
  description text,
  frequency public.collection_frequency not null,
  collections_per_period integer not null check (collections_per_period > 0),
  price_ugx numeric(14, 2) not null check (price_ugx >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.customer_details (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null unique references public.profiles (id) on delete cascade,
  phone_e164 text not null unique check (phone_e164 ~ '^\+256[0-9]{9}$'),
  full_name text not null check (length(btrim(full_name)) between 2 and 160),
  district text not null check (length(btrim(district)) between 2 and 100),
  town text not null check (length(btrim(town)) between 1 and 100),
  division text,
  area text,
  village text,
  street text,
  house_number text,
  landmark text,
  latitude numeric(9, 6) check (latitude between -90 and 90),
  longitude numeric(9, 6) check (longitude between -180 and 180),
  approval_status public.approval_status not null default 'pending',
  account_status text not null default 'pending' check (account_status in ('pending', 'active', 'suspended', 'closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check ((latitude is null) = (longitude is null))
);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customer_details (id) on delete restrict,
  service_plan_id uuid not null references public.service_plans (id) on delete restrict,
  frequency public.collection_frequency not null,
  collections_per_period integer not null check (collections_per_period > 0),
  agreed_price_ugx numeric(14, 2) not null check (agreed_price_ugx >= 0),
  status public.subscription_status not null default 'pending',
  starts_on date,
  ends_on date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_on is null or starts_on is null or ends_on >= starts_on)
);

create index customer_details_area_idx on public.customer_details (district, town, area);
create index customer_details_status_idx on public.customer_details (approval_status, account_status);
create index subscriptions_customer_idx on public.subscriptions (customer_id, created_at desc);
create index subscriptions_status_idx on public.subscriptions (status);
create index service_plans_active_idx on public.service_plans (is_active) where is_active;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger profiles_set_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

create trigger service_plans_set_updated_at
before update on public.service_plans
for each row execute function public.set_updated_at();

create trigger customer_details_set_updated_at
before update on public.customer_details
for each row execute function public.set_updated_at();

create trigger subscriptions_set_updated_at
before update on public.subscriptions
for each row execute function public.set_updated_at();

create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, role)
  values (new.id, 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_auth_user();

create or replace function public.current_app_role()
returns public.app_role
language sql
stable
security definer
set search_path = ''
as $$
  select p.role from public.profiles p where p.id = (select auth.uid())
$$;

create or replace function public.submit_customer_application(
  p_full_name text,
  p_district text,
  p_town text,
  p_division text,
  p_area text,
  p_village text,
  p_street text,
  p_house_number text,
  p_landmark text,
  p_latitude numeric,
  p_longitude numeric,
  p_service_plan_id uuid
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_profile_id uuid := auth.uid();
  v_customer_id uuid;
  v_plan public.service_plans%rowtype;
  v_phone text;
  v_phone_confirmed_at timestamptz;
begin
  if v_profile_id is null then
    raise exception 'Authentication is required.' using errcode = '28000';
  end if;

  if public.current_app_role() is distinct from 'customer' then
    raise exception 'Only customer accounts can submit a customer application.' using errcode = '42501';
  end if;

  select u.phone, u.phone_confirmed_at
  into v_phone, v_phone_confirmed_at
  from auth.users u
  where u.id = v_profile_id;

  if v_phone is null
    or v_phone !~ '^\+256[0-9]{9}$'
    or v_phone_confirmed_at is null then
    raise exception 'A verified Ugandan phone number is required.' using errcode = '22023';
  end if;

  if exists (select 1 from public.customer_details d where d.profile_id = v_profile_id) then
    raise exception 'A customer application already exists for this account.' using errcode = '23505';
  end if;

  select * into v_plan
  from public.service_plans p
  where p.id = p_service_plan_id and p.is_active;

  if not found then
    raise exception 'The selected collection plan is not available.' using errcode = '22023';
  end if;

  insert into public.customer_details (
    profile_id, phone_e164, full_name, district, town, division, area,
    village, street, house_number, landmark, latitude, longitude
  )
  values (
    v_profile_id, v_phone, btrim(p_full_name), btrim(p_district), btrim(p_town),
    nullif(btrim(p_division), ''), nullif(btrim(p_area), ''),
    nullif(btrim(p_village), ''), nullif(btrim(p_street), ''),
    nullif(btrim(p_house_number), ''), nullif(btrim(p_landmark), ''),
    p_latitude, p_longitude
  )
  returning id into v_customer_id;

  insert into public.subscriptions (
    customer_id, service_plan_id, frequency, collections_per_period, agreed_price_ugx
  )
  values (
    v_customer_id, v_plan.id, v_plan.frequency, v_plan.collections_per_period, v_plan.price_ugx
  );

  update public.profiles
  set full_name = btrim(p_full_name)
  where id = v_profile_id;

  return v_customer_id;
end;
$$;

revoke all on function public.handle_new_auth_user() from public, anon, authenticated;
revoke all on function public.current_app_role() from public, anon;
revoke all on function public.submit_customer_application(text, text, text, text, text, text, text, text, text, numeric, numeric, uuid) from public, anon;
grant execute on function public.current_app_role() to authenticated;
grant execute on function public.submit_customer_application(text, text, text, text, text, text, text, text, text, numeric, numeric, uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.service_plans enable row level security;
alter table public.customer_details enable row level security;
alter table public.subscriptions enable row level security;

create policy "Profiles are visible to their owner and administrators"
on public.profiles for select to authenticated
using (id = (select auth.uid()) or (select public.current_app_role()) = 'administrator');

create policy "Active service plans are visible"
on public.service_plans for select to anon, authenticated
using (is_active);

create policy "Administrators view all service plans"
on public.service_plans for select to authenticated
using ((select public.current_app_role()) = 'administrator');

create policy "Administrators manage service plans"
on public.service_plans for all to authenticated
using ((select public.current_app_role()) = 'administrator')
with check ((select public.current_app_role()) = 'administrator');

create policy "Customers and administrators can view customer details"
on public.customer_details for select to authenticated
using (
  profile_id = (select auth.uid())
  or (select public.current_app_role()) in ('administrator', 'staff')
);

create policy "Administrators manage customer details"
on public.customer_details for all to authenticated
using ((select public.current_app_role()) = 'administrator')
with check ((select public.current_app_role()) = 'administrator');

create policy "Customers and administrators can view subscriptions"
on public.subscriptions for select to authenticated
using (
  exists (
    select 1 from public.customer_details d
    where d.id = customer_id and d.profile_id = (select auth.uid())
  )
  or (select public.current_app_role()) = 'administrator'
);

create policy "Administrators manage subscriptions"
on public.subscriptions for all to authenticated
using ((select public.current_app_role()) = 'administrator')
with check ((select public.current_app_role()) = 'administrator');

revoke all on public.profiles, public.customer_details, public.subscriptions from anon;
grant select on public.profiles to authenticated;
grant select, insert, update, delete on public.customer_details, public.subscriptions to authenticated;
grant select on public.service_plans to anon, authenticated;
grant insert, update, delete on public.service_plans to authenticated;
