/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        forest: "#174b37",
        leaf: "#2f8059",
        mist: "#f6f8f5",
        ink: "#202a25"
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"]
      },
      boxShadow: {
        card: "0 18px 55px rgba(27, 55, 39, 0.08)"
      }
    }
  },
  plugins: []
};
